
const express = require("express");
const  mongoose = require("mongoose");

const app = express();

mongoose.connect("mongodb+srv://dbEventPlaning:EventPlaning$@cluster0.lranp.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0");

app.use(express.static("mainProj"));
app.use(express.json());

const cors = require('cors');
app.use(cors());
const EventPlaningSchema = new mongoose.Schema({
    eventType: String,
    date: Date,
    SuggesetionTheme: String, 
    Location: String,
    Guset: [String],
 });


 const userDataSchema = new mongoose.Schema({
    userName: String,
    userPass: String,
 });

 const adminDataSchema = new mongoose.Schema({
    adminName: String,
    adminPass: String,
 });

 const EventPlaning = mongoose.model('EventPlaning' , EventPlaningSchema);
 const userdata = mongoose.model('userdata', userDataSchema);
 const admindata = mongoose.model('admindata', adminDataSchema);


 app.post("/EventPlaning/add", async(req, res)=>{
    const{eventType, date, SuggesetionTheme, guests, Location} = req.body;
    console.log(req.query);

    const evPdata = new EventPlaning({date: date, eventType: eventType,   SuggesetionTheme: SuggesetionTheme, Guset:guests, Location: Location});
    await evPdata.save();

    res.send("Done addded");
})

app.get("/EventPlaning/get", async (req, res)=>{
    const evPdata = await EventPlaning.find();

    res.send(evPdata)
})

app.delete("/event", async(req, res)=>{
    const {Location }= req.query; 
    const userData = await userData.deleteOne({Location});

    res.send(userData)
})



app.post("/EventPlaning/add", async (req, res)=>{
    const{userName, userPass} = req.body;
    console.log(req.body);

    const userData = new userdata({userName: userName, userPass: userPass});
    await userData.save();

    res.send("Login Successed");
})

app.get("/EventPlaning/get", async (req, res)=>{
    const userData = userdata.find();

    res.send(userData)
})

app.delete("/user", async(req, res)=>{
    const {userName }= req.query; 
    const userData = await userData.deleteOne({adminName});

    res.send(userData)
})

app.post("/EventPlaning/add", async (req, res)=>{
    const{adminName, adminPass} = req.body;
    console.log(req.body);

    const adminData = new admindata({adminName: adminName, adminPass: adminPass});
    await adminData.save();

    res.send("Login Successed");
})

app.get("/EventPlaning/get", async(req, res)=>{
    const adminData = await admindata.find();

    res.send(adminData)
})

app.delete("/admin", async(req, res)=>{
    const {adminName} = req.query;
    const adminData =await admindata.deleteOne({ adminName });
    res.send(adminData)
})

app.listen(4000);