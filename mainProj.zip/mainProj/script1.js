function buttonClick() {

    const eventType = document.getElementById('eventType').value;
    const date = document.getElementById('date').value;
    const suggestionTheme = document.getElementById('SuggesetionTheme').value;
    const location = document.getElementById('location').value;
    const guests = document.getElementById('Guest').value.split(',');


    fetch('/EventPlaning/add', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ eventType, date, suggestionTheme: "", guests, location }),
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('adding refused ' + response.statusText);
            }
            return response.text();
        })
        .then(result => {
            alert(result);
        })
        .catch(error => {
            console.error('There was a problem with the fetch operation:', error);
            alert('Error: ' + error.message);
        });
};

