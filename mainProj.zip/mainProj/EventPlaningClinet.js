
// fetch("http://localhost:4000/EventPlaning")
// .then(res=> res.json())

// .then(data=>{
//     console.log(data);
//     const myElement = document.getElementById("content");
//     for(let i = 0; i < data.length; i++){
//         myElement.innerHTML += `<p class="sdata">${data[i]} got ${data[i]}</p>`
//     }
// });



// let btnAdmin = document.getElementById("signs");
// btnAdmin.addEventListener('click', function(event) {

//     const userName = document.getElementById('userName').value;
//     const userPass = document.getElementById('userPass').value;

    
//     fetch('//EventPlaning/add', {
//         method: 'POST',
//         headers: {
//             'Content-Type': 'application/json',
//         },
//         body: JSON.stringify({ userName, userPass }),
//     })
//     .then(response => {
//         if (!response.ok) {
//             throw new Error('Network response was not ok ' + response.statusText);
//         }
//         return response.text(); 
//     })
//     .then(result => {
//         alert(result);
//     })
//     .catch(error => {
//         console.error('There was a problem with the fetch operation:', error);
//         alert('Error: ' + error.message); 
//     });
// });

//------------------------------------------------------------------------------------------------------------------

function buttonClick() {
let btnAdmin = document.getElementById("signs");
btnAdmin.addEventListener('click', function(event)  {
    event.preventDefault(); 

    const adminName = document.getElementById('adminName').value;
    const adminPass = document.getElementById('adminPass').value;

    
    fetch('/EventPlaning/add', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ adminName, adminPass }),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok ' + response.statusText);
        }
        return response.text(); 
    })
    .then(result => {
        alert(result);
    })
    .catch(error => {
        console.error('There was a problem with the fetch operation:', error);
        alert('Error: ' + error.message); 
    });
}); 
}

//---------------------------------------------------------------------------------------------------------------------
